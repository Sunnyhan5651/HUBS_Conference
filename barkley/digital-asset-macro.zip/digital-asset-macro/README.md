# 디지털 자산 제도화 × 매크로 반응 분석

가상자산 공모전 **「디지털 자산의 제도화와 국내 기업의 대응 전략」** Part 1(정량 분석) 중 **매크로 파트** 저장소입니다.
미국의 크립토 제도화 이벤트(법안 통과, ETF 승인, SEC 제소 등)가 미국 금리를 움직였는지 이벤트 스터디로 검증했습니다.

**결론 한 줄:** 미국 크립토 제도화 이벤트 22건이 미국 금리를 체계적으로 움직였다는 증거는 약하다. → [최종 보고서 보기](report/rates_event_study_report.md)

## 폴더 구조

```
digital-asset-macro/
├── README.md
├── requirements.txt
├── report/
│   ├── rates_event_study_report.md      ← 최종 보고서 (코드 몰라도 읽을 수 있게 작성)
│   └── figures/                          ← 보고서 그림
└── rates_event_study/                    ← 분석 코드 (여기서 실행)
    ├── step1_fred_rates.ipynb            ① FRED에서 미국 금리 9개 다운로드
    ├── step2_clean_rates.ipynb           ② 휴장일 정리, 3M−SOFR 스프레드, bp 변화 변환
    ├── step3_align_events.ipynb          ③ 이벤트 날짜를 거래일(t0)에 맞추기
    ├── step4_event_car.ipynb             ④ 비정상 변화(AR)·누적 비정상 변화(CAR) 계산
    ├── step5_stat_tests.ipynb            ⑤ FOMC·CPI 오염 판정 + 통계 검정 4종 + FDR
    ├── step6_compare_samples.ipynb       ⑥ 전체 vs 오염 제외 표본 비교, 그림·엑셀 출력
    ├── 최종_이벤트_리스트.xlsx             이벤트 49개 (Main 22 / Robust 27), 분류 사유, 변경 기록
    ├── results_step6_전체vs오염제외.xlsx    2026-10-12 실행 결과
    └── data/                             실행하면 데이터·결과가 여기에 생김 (git에는 안 올림)
```

## 실행 방법

1. Python 3.10 이상과 Jupyter를 준비합니다. (Anaconda 설치 시 대부분 포함)
2. 필요한 패키지를 설치합니다.
   ```bash
   pip install -r requirements.txt
   ```
3. `rates_event_study` 폴더로 이동해서 **Step 1 → 6 순서대로** 노트북을 실행합니다.
   노트북은 같은 폴더의 `data/`와 `최종_이벤트_리스트.xlsx`를 상대 경로로 읽기 때문에, **반드시 이 폴더 안에서 실행**해야 합니다.
   ```bash
   cd rates_event_study
   jupyter notebook
   ```
   한 번에 전부 돌리려면:
   ```bash
   cd rates_event_study
   for n in 1_fred_rates 2_clean_rates 3_align_events 4_event_car 5_stat_tests 6_compare_samples; do
     jupyter nbconvert --to notebook --execute --inplace step$n.ipynb
   done
   ```

> **주의**
> - Step 1은 인터넷 연결이 필요합니다 (FRED CSV 다운로드, API 키 불필요). 학교·회사 네트워크에서 막히면 노트북 안의 수동 다운로드 방법을 참고하세요.
> - 그래프의 한글 폰트는 Windows 기준 `Malgun Gothic`입니다. Mac이면 각 노트북 위쪽의 폰트를 `AppleGothic`으로 바꾸세요.
> - FRED 데이터는 수시로 갱신되므로, 다시 받으면 결과 숫자가 보고서와 소수점 수준에서 조금 다를 수 있습니다.

## 방법론 요약

| 항목 | 설정 |
| --- | --- |
| 데이터 | FRED 일별 금리 (DGS1MO, DGS3MO, SOFR, DGS2, DGS5, DGS10, DGS30, T10Y2Y, T10Y3M) + 3개월 국채 − SOFR |
| 단위 | 일별 bp 변화 (빈칸은 채우지 않음) |
| 이벤트 날(t0) | 미 동부 장 마감 후 발표·주말·공휴일이면 다음 거래일 |
| 정상 변화 | 평균 조정 모형, 추정 구간 τ = −125 ~ −6 (120거래일) |
| 이벤트 구간 | 메인 [−5, +5], 보조 [−1, +1] |
| 방향 보정 | 제도 후퇴(−1) 이벤트의 CAR에 −1을 곱해 진전 이벤트와 통합 |
| 검정 | BMP(메인), t검정, 부호 검정, placebo 2,000회, Benjamini–Hochberg FDR |
| 오염 정의 | 해당 구간 안에 FOMC 결정일 또는 CPI 발표일(BLS 공식 기록)이 있는 이벤트 |

자세한 설명과 결과 해석은 [보고서](report/rates_event_study_report.md)를 보세요.

## 다음 작업

- [ ] 오염 달력에 고용지표(NFP)·재무부 국채 리펀딩 발표일 추가
- [ ] USD/KRW·달러지수로 확장 (국내 전이 가설)
- [ ] VIX·MOVE·하이일드 스프레드 (위험선호 대조군)
- [ ] 은행·결제 주가 (스테이블코인의 예금 대체 경로)
- [ ] 3개월 − SOFR와 스테이블코인 시가총액의 장기(월별) 관계
