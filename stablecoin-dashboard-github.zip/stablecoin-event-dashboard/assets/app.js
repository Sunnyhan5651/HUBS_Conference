// Dashboard state, chart rendering, event analysis and CSV export.
"use strict";
const D = window.STABLECOIN_DATA,
  A = D.assets,
  E = D.events,
  dates = D.dates;
const $ = (id) => document.getElementById(id),
  esc = (x) =>
    String(x).replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
const colors = {
  BTC: "#d89024",
  ETH: "#6178d4",
  SOL: "#159c8b",
  CRCL: "#245fd2",
  COIN: "#8c61bf",
  PYPL: "#c07837",
  HOOD: "#1d9472",
  V: "#485ba4",
  MA: "#b45d73",
  SPY: "#8a97a8",
  USDT: "#148b73",
  USDC: "#3d73ce",
  IRX: "#d39639",
  TNX: "#5977c4",
  BIL: "#8a97a8",
};
const categories = {
  입법: "#426ed0",
  규제: "#8c7eae",
  신뢰충격: "#bc5564",
  채택: "#289982",
  기업: "#bb8a46",
  정책지원: "#289982",
};
const windows = {
  d0: "당일 [0]",
  d1: "[0,+1]",
  m1p1: "[-1,+1]",
  d3: "[0,+3]",
  d5: "[0,+5]",
  d10: "[0,+10]",
};
let state = {
  start: D.start,
  end: D.end,
  event: E[E.length - 1].id,
  window: "d0",
  crypto: ["BTC", "ETH", "SOL"],
  stocks: ["CRCL", "COIN", "PYPL", "HOOD", "V", "MA", "SPY"],
  stable: ["USDT", "USDC"],
  eventKeys: ["BTC", "ETH", "SOL", "CRCL", "COIN"],
  category: "all",
};
const nfmt = (x, d = 2) =>
    x == null
      ? "N/A"
      : Number(x).toLocaleString("en-US", {
          maximumFractionDigits: d,
          minimumFractionDigits: d,
        }),
  signed = (x, d = 2) => (x == null ? "N/A" : (x > 0 ? "+" : "") + nfmt(x, d)),
  cls = (x) =>
    x == null ? "neutral" : x > 0 ? "up" : x < 0 ? "down" : "neutral";
const event = () => E.find((x) => x.id === state.event),
  idx = (d) => dates.indexOf(d);
const numShort = (v) =>
  Math.abs(v) >= 1e6
    ? (v / 1e6).toFixed(1) + "m"
    : Math.abs(v) >= 1000
      ? (v / 1000).toFixed(v >= 10000 ? 0 : 1) + "k"
      : Math.abs(v) >= 10
        ? v.toFixed(0)
        : Math.abs(v) >= 1
          ? v.toFixed(1)
          : v.toFixed(2);
function tooltip(html, x, y) {
  const t = $("tooltip");
  t.innerHTML = html;
  t.style.display = "block";
  let xx = Math.min(x + 15, innerWidth - t.offsetWidth - 12),
    yy = Math.min(y + 12, innerHeight - t.offsetHeight - 10);
  t.style.left = Math.max(6, xx) + "px";
  t.style.top = Math.max(6, yy) + "px";
}
function hideTip() {
  $("tooltip").style.display = "none";
}
function makeLegend(id, all, selected, callback) {
  $(id).innerHTML = all
    .map(
      (k) =>
        `<button aria-pressed="${selected.includes(k)}" data-key="${k}" class="${selected.includes(k) ? "" : "off"}" title="${esc(A[k].name)}"><i class="swatch" style="background:${colors[k]}"></i>${k}</button>`,
    )
    .join("");
  $(id)
    .querySelectorAll("button")
    .forEach(
      (b) =>
        (b.onclick = () => {
          const k = b.dataset.key;
          if (selected.includes(k)) {
            if (selected.length === 1) return;
            selected.splice(selected.indexOf(k), 1);
          } else selected.push(k);
          callback();
        }),
    );
}
function showEvent(id, scroll = false) {
  state.event = id;
  $("eventSelect").value = id;
  renderFocus();
  renderEventChart();
  renderHeatmap();
  renderDetail();
  renderMain();
  if (scroll)
    $("eventFocus").scrollIntoView({ behavior: "smooth", block: "start" });
}
function visibleEvents() {
  return E.filter((e) => e.date >= state.start && e.date <= state.end);
}
function lineChart(id, series, opts = {}) {
  const host = $(id),
    W = Math.max(320, host.clientWidth),
    H = host.clientHeight,
    L = 58,
    R = 17,
    T = opts.annotations ? 53 : 25,
    B = 32,
    pw = W - L - R,
    ph = H - T - B;
  let pts = series.flatMap((s) => s.values),
    xlo = opts.xlo,
    xhi = opts.xhi;
  if (!pts.length) {
    host.innerHTML =
      '<div class="notice">선택 구간에 관측 데이터가 없습니다.</div>';
    return;
  }
  if (xlo == null) xlo = Math.min(...pts.map((p) => p.x));
  if (xhi == null) xhi = Math.max(...pts.map((p) => p.x));
  const log = !!opts.log,
    trans = (y) => (log ? Math.log10(Math.max(y, 1e-12)) : y);
  let ys = pts.map((p) => trans(p.y));
  let ymin = Math.min(...ys),
    ymax = Math.max(...ys);
  if (opts.zero) {
    ymin = Math.min(ymin, 0);
    ymax = Math.max(ymax, 0);
  }
  if (ymax === ymin) {
    ymin -= 1;
    ymax += 1;
  }
  const pad = (ymax - ymin) * 0.09;
  ymin -= pad;
  ymax += pad;
  const X = (x) => L + ((x - xlo) / (xhi - xlo || 1)) * pw,
    Y = (y) => T + (1 - (trans(y) - ymin) / (ymax - ymin)) * ph;
  const uid = id + "clip";
  let h = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(opts.label || id)}"><defs><clipPath id="${uid}"><rect x="${L}" y="${T}" width="${pw}" height="${ph}"/></clipPath></defs>`;
  for (let i = 0; i < 5; i++) {
    let yy = ymin + ((ymax - ymin) * i) / 4,
      y = T + ph - (i * ph) / 4,
      val = log ? 10 ** yy : yy;
    h += `<line x1="${L}" y1="${y}" x2="${W - R}" y2="${y}" stroke="#e9edf3"/><text x="${L - 8}" y="${y + 3}" text-anchor="end">${numShort(val)}</text>`;
  }
  h += `<text x="${L}" y="${T - 10}" style="font-size:10px">${esc(opts.unit || "")}</text>`;
  const nt = W < 450 ? 4 : 5;
  for (let i = 0; i < nt; i++) {
    let xx = xlo + ((xhi - xlo) * i) / (nt - 1),
      x = X(xx),
      label = opts.eventAxis
        ? (Math.round(xx) > 0 ? "+" : "") + Math.round(xx)
        : dates[Math.max(0, Math.min(dates.length - 1, Math.round(xx)))].slice(
            0,
            7,
          );
    h += `<text x="${x}" y="${H - 9}" text-anchor="${i === 0 ? "start" : i === nt - 1 ? "end" : "middle"}">${label}</text>`;
  }
  if (opts.zero && ymin < 0 && ymax > 0)
    h += `<line x1="${L}" y1="${Y(0)}" x2="${W - R}" y2="${Y(0)}" stroke="#9aaabd" stroke-dasharray="3 3"/>`;
  if (opts.eventAxis)
    h += `<line x1="${X(0)}" y1="${T}" x2="${X(0)}" y2="${H - B}" stroke="#8599b8" stroke-dasharray="4 3"/><text x="${X(0) + 5}" y="${T + 12}">이벤트 t0</text>`;
  if (opts.annotations) {
    for (const e of visibleEvents()) {
      const x = X(idx(e.date));
      h += `<line x1="${x}" y1="${T}" x2="${x}" y2="${H - B}" stroke="${e.id === state.event ? "#7498d8" : "#d8e1ee"}" stroke-width="${e.id === state.event ? 1.3 : 0.6}" stroke-dasharray="2 3"/>`;
    }
  }
  for (const s of series) {
    let path = s.values
      .map(
        (p, i) => (i ? "L" : "M") + X(p.x).toFixed(2) + "," + Y(p.y).toFixed(2),
      )
      .join(" ");
    h += `<path d="${path}" clip-path="url(#${uid})" stroke="${colors[s.key]}" fill="none" stroke-width="${s.key === "SPY" ? 1.2 : 1.8}" ${s.key === "SPY" ? 'stroke-dasharray="4 3"' : ""}/>`;
  }
  h += `<rect data-hover x="${L}" y="${T}" width="${pw}" height="${ph}" fill="transparent"/><line data-cross x1="0" x2="0" y1="${T}" y2="${H - B}" stroke="#94a3b8" style="display:none"/>`;
  if (opts.annotations) {
    let lastLabel = -1000;
    const shown = visibleEvents();
    for (let i = 0; i < shown.length; i++) {
      const e = shown[i],
        x = X(idx(e.date)),
        move = e.responses[opts.reference || "BTC"]?.windows?.d0?.change,
        col = move == null ? "#8b99ad" : move >= 0 ? "#178567" : "#c15362",
        cy = T - 9 - (i % 2) * 14;
      h += `<circle class="marker" data-event="${e.id}" cx="${x}" cy="${cy}" r="${e.id === state.event ? 5 : 3.5}" fill="${col}" stroke="white" stroke-width="1"><title>${esc(e.date + " " + e.label + " / " + (opts.reference || "BTC") + " " + signed(move) + "%")}</title></circle>`;
      const important =
        e.id === state.event ||
        /디페깅|Terra|SVB·|서명|절차 부결|IPO/.test(e.short);
      if (important && x - lastLabel > 78 && x < W - 78) {
        h += `<text class="event-label marker" data-event="${e.id}" x="${x + 3}" y="13">${esc(e.short)}</text>`;
        lastLabel = x;
      }
    }
  }
  h += "</svg>";
  host.innerHTML = h;
  host.querySelectorAll("[data-event]").forEach((n) => {
    n.onclick = () => showEvent(n.dataset.event);
    n.onpointerenter = (e) => {
      let v = E.find((x) => x.id === n.dataset.event);
      tooltip(
        `<strong>${esc(v.date + " " + v.short)}</strong><div>${esc(v.label)}</div><small>클릭해서 자산별 반응 비교</small>`,
        e.clientX,
        e.clientY,
      );
    };
    n.onpointerleave = hideTip;
  });
  const overlay = host.querySelector("[data-hover]"),
    cross = host.querySelector("[data-cross]");
  overlay.onpointermove = (ev) => {
    const rect = host.getBoundingClientRect(),
      px = ev.clientX - rect.left;
    const xx = xlo + ((px - L) / pw) * (xhi - xlo);
    cross.setAttribute("x1", px);
    cross.setAttribute("x2", px);
    cross.style.display = "block";
    let text = `<strong>${opts.eventAxis ? "상대 관측일 " + Math.round(xx) : dates[Math.max(0, Math.min(dates.length - 1, Math.round(xx)))]}</strong>`;
    for (const s of series) {
      let best = s.values.reduce((b, p) =>
        Math.abs(p.x - xx) < Math.abs(b.x - xx) ? p : b,
      );
      if (Math.abs(best.x - xx) > Math.max(4, ((xhi - xlo) / pw) * 5)) continue;
      text += `<div class="tiprow"><span><i class="swatch" style="background:${colors[s.key]}"></i>${s.key}</span><span>${nfmt(best.y, opts.precision ?? 2)} ${esc(opts.unit || "")}</span></div>`;
      if (best.date)
        text += `<small>${best.date}${best.raw != null ? " · 원값 " + nfmt(best.raw, 4) : ""}</small>`;
    }
    tooltip(text, ev.clientX, ev.clientY);
  };
  overlay.onpointerleave = () => {
    cross.style.display = "none";
    hideTip();
  };
}
function mainSeries(keys, mode) {
  let lo = idx(state.start),
    hi = idx(state.end);
  return keys
    .map((k) => {
      let a = A[k],
        source = a.a,
        vals = [];
      for (let i = lo; i <= hi; i++)
        if (source[i] != null)
          vals.push({ x: i, y: source[i], raw: a.p[i], date: dates[i] });
      if (mode.startsWith("index") && vals.length) {
        let base = vals[0].y;
        vals = vals.map((p) => ({ ...p, y: (p.y / base) * 100 }));
      } else if (mode === "bp")
        vals = vals.map((p) => ({ ...p, y: (p.y - 1) * 10000 }));
      return { key: k, values: vals };
    })
    .filter((s) => s.values.length);
}
function renderMain() {
  const cm = $("cryptoMode").value;
  makeLegend("cryptoLegend", ["BTC", "ETH", "SOL"], state.crypto, renderMain);
  lineChart("cryptoChart", mainSeries(state.crypto, cm), {
    log: cm.endsWith("Log"),
    annotations: true,
    unit: cm.startsWith("index") ? "지수 (첫 값=100)" : "USD",
    xlo: idx(state.start),
    xhi: idx(state.end),
    label: "대표 코인 가격 시계열",
  });
  makeLegend(
    "stockLegend",
    ["CRCL", "COIN", "PYPL", "HOOD", "V", "MA", "SPY"],
    state.stocks,
    renderMain,
  );
  lineChart("stockChart", mainSeries(state.stocks, "indexLog"), {
    log: true,
    annotations: true,
    reference: "COIN",
    unit: "수정주가 지수",
    xlo: idx(state.start),
    xhi: idx(state.end),
    label: "발행·사업 관련주 수정주가",
  });
  const sm = $("stableMode").value;
  makeLegend("stableLegend", ["USDT", "USDC"], state.stable, renderMain);
  lineChart("stableChart", mainSeries(state.stable, sm), {
    annotations: true,
    reference: "USDT",
    zero: sm === "bp",
    unit: sm === "bp" ? "bp" : "USD",
    precision: sm === "bp" ? 2 : 6,
    xlo: idx(state.start),
    xhi: idx(state.end),
    label: "스테이블코인 페그 이탈",
  });
}
function renderFocus() {
  const e = event(),
    w = state.window;
  $("focusNote").innerHTML =
    `<strong>${esc(e.id + " · " + e.date + " · " + e.label)}</strong> <span class="pill">${esc(e.category)}</span> <a href="${e.url}" target="_blank" rel="noopener">원문 ↗</a>`;
  const keys = ["BTC", "ETH", "SOL", "CRCL", "COIN", "USDT"];
  $("metrics").innerHTML = keys
    .map((k) => {
      const r = e.responses[k],
        v = r?.windows[w],
        val = k === "USDT" ? v?.peg_change_bp : v?.change;
      return `<div class="metric"><label>${k}${k === "CRCL" ? " · 직접 발행사" : k === "USDT" ? " · 페그 변화" : ""}</label><strong class="${cls(val)}">${signed(val)}<span style="font-size:13px">${k === "USDT" ? "bp" : "%"}</span></strong><small>${v ? esc(v.base_date + " → " + v.end_date) : "기준 관측값 없음"}</small></div>`;
    })
    .join("");
  const overlapping = [
    ...new Set(
      Object.values(e.responses)
        .flatMap((r) => (r.windows[w]?.overlapping_events || "").split(";"))
        .filter(Boolean),
    ),
  ];
  $("focusCaution").textContent =
    `${windows[w]} 기준 · 자산별 반응 날짜는 위에 표시. ${overlapping.length ? "다른 수록 이벤트와 구간 중복: " + overlapping.join(", ") + ". " : ""}입법 진전·차질과 실제 가격 반응의 부호는 다를 수 있습니다.`;
}
function renderEventChart() {
  const e = event(),
    g = $("eventGroup").value;
  let all =
    g === "stable"
      ? ["USDT", "USDC"]
      : g === "rates"
        ? ["IRX", "TNX"]
        : ["BTC", "ETH", "SOL", "CRCL", "COIN", "PYPL", "HOOD", "SPY"];
  if (state.lastGroup !== g) {
    state.eventKeys =
      g === "risk" ? ["BTC", "ETH", "SOL", "CRCL", "COIN"] : all.slice();
    state.lastGroup = g;
  }
  makeLegend("eventLegend", all, state.eventKeys, renderEventChart);
  $("eventChartSub").textContent =
    e.date +
    " · " +
    e.short +
    (g === "stable"
      ? " · $1 기준"
      : g === "rates"
        ? " · t−1 대비"
        : " · t−1 가격 대비");
  let ser = state.eventKeys
    .map((k) => ({
      key: k,
      values: (e.responses[k]?.path || []).map((p) => ({
        x: p[0],
        y: p[1],
        date: p[2],
      })),
    }))
    .filter((s) => s.values.length);
  lineChart("eventChart", ser, {
    eventAxis: true,
    zero: true,
    xlo: -10,
    xhi: 20,
    unit: g === "stable" || g === "rates" ? "bp" : "%",
    label: "선택 이벤트 전후 가격 반응",
  });
}
function heatColor(v, stable = false) {
  if (v == null) return "";
  let alpha = Math.min(0.24, 0.04 + (Math.abs(v) / (stable ? 40 : 20)) * 0.2);
  return `background:rgba(${v >= 0 ? "20,139,109" : "190,61,77"},${alpha})`;
}
function renderHeatmap() {
  const keys = [
      "BTC",
      "ETH",
      "SOL",
      "CRCL",
      "COIN",
      "PYPL",
      "HOOD",
      "V",
      "MA",
      "USDT",
      "USDC",
    ],
    excess = $("stockMetric").value === "excess",
    w = state.window;
  let es = E.slice()
    .reverse()
    .filter(
      (e) =>
        ($("category").value === "all" || e.category === $("category").value) &&
        (!$("rangeEvents").checked ||
          (e.date >= state.start && e.date <= state.end)),
    );
  let h =
    "<table><thead><tr><th>이벤트 · " +
    windows[w] +
    "</th>" +
    keys
      .map(
        (k) =>
          `<th>${k}<br><small>${A[k].kind === "stable" ? "Δbp" : excess && A[k].kind === "stock" ? "초과 %p" : "%"}</small></th>`,
      )
      .join("") +
    "</tr></thead><tbody>";
  for (const e of es) {
    let overlap = false;
    let cells = keys
      .map((k) => {
        const r = e.responses[k]?.windows[w];
        if (r?.overlapping_events) overlap = true;
        let val =
          A[k].kind === "stable"
            ? r?.peg_change_bp
            : excess && A[k].kind === "stock"
              ? r?.excess_spy_pp
              : r?.change;
        let title = r
          ? `${r.base_date} → ${r.end_date}; 기준 ${r.base}; 최종 ${r.end}; 다른 이벤트 ${r.overlapping_events || "없음"}`
          : "당시 데이터 또는 기준 가격 없음";
        return `<td style="${heatColor(val, A[k].kind === "stable")}" class="${cls(val)}" title="${esc(title)}">${signed(val)}</td>`;
      })
      .join("");
    h += `<tr data-event="${e.id}" class="${e.id === state.event ? "selected" : ""}"><td><span class="date">${e.id} · ${e.date} <span class="pill">${e.category}</span>${overlap ? '<span class="pill">중복</span>' : ""}</span><span class="event-name" title="${esc(e.label)}">${esc(e.label)}</span></td>${cells}</tr>`;
  }
  h += "</tbody></table>";
  $("heatmap").innerHTML = h;
  $("heatmap")
    .querySelectorAll("[data-event]")
    .forEach((r) => (r.onclick = () => showEvent(r.dataset.event, true)));
}
function renderDetail() {
  const e = event();
  $("selectedTitle").textContent = e.id + " · " + e.label;
  const policy =
    e.direction === 1
      ? "진전·채택"
      : e.direction === -1
        ? "차질·신뢰 충격"
        : "혼합·방향 미정";
  $("eventDetail").innerHTML =
    `<p><strong>공개일</strong> ${e.date} / ${e.scope} / ${e.category} / ${policy}</p><p>${esc(e.note)}</p><p><strong>분석 날짜</strong> 코인: ${e.cryptoDate}, 주식: ${e.stockDate} 이후 첫 유효 관측일.</p><p><a href="${e.url}" target="_blank" rel="noopener">공식 발표·사건 원문 확인 ↗</a></p><p>현재 화면의 값은 원자료에서 직접 계산한 구간 반응입니다. 입법 뉴스 이외의 거시·기업 정보가 포함될 수 있습니다.</p>`;
}
function renderMovers() {
  const k = $("moverAsset").value,
    a = A[k];
  let rows = [],
    prev = null;
  for (let i = 0; i < dates.length; i++) {
    const v = a.a[i];
    if (v == null) continue;
    if (prev != null && dates[i] >= state.start && dates[i] <= state.end)
      rows.push({ date: dates[i], r: (v / prev - 1) * 100 });
    prev = v;
  }
  let sorted = rows.sort((a, b) => b.r - a.r);
  let chosen = [...sorted.slice(0, 3), ...sorted.slice(-3).reverse()];
  $("movers").innerHTML =
    "<table><thead><tr><th>날짜</th><th>수익률</th><th>주변 수록 이벤트 (±3일)</th></tr></thead><tbody>" +
    chosen
      .map((r) => {
        let near = E.filter((e) => Math.abs(idx(r.date) - idx(e.date)) <= 3);
        return `<tr><td>${r.date}</td><td class="${cls(r.r)}">${signed(r.r)}%</td><td>${near.length ? near.map((e) => `<a href="#eventFocus" data-event="${e.id}">${e.id} ${esc(e.short)}</a>`).join("<br>") : "대응 이벤트 미확인"}</td></tr>`;
      })
      .join("") +
    "</tbody></table>";
  $("movers")
    .querySelectorAll("[data-event]")
    .forEach((b) => (b.onclick = () => showEvent(b.dataset.event)));
}
function applyRange(start, end) {
  if (start < D.start) start = D.start;
  if (end > D.end) end = D.end;
  if (start >= end) {
    alert("종료일은 시작일보다 뒤여야 합니다.");
    return;
  }
  state.start = start;
  state.end = end;
  $("startDate").value = start;
  $("endDate").value = end;
  document
    .querySelectorAll("[data-range]")
    .forEach((b) => b.classList.remove("active"));
  renderMain();
  renderMovers();
  if ($("rangeEvents").checked) renderHeatmap();
}
function csvDownload(name, headers, rows) {
  const quote = (v) =>
    v == null ? "" : '"' + String(v).replaceAll('"', '""') + '"';
  const csv =
    "\ufeff" +
    [headers, ...rows].map((r) => r.map(quote).join(",")).join("\r\n");
  download(name, csv, "text/csv;charset=utf-8");
}
function download(name, data, type) {
  const blob = new Blob([data], { type }),
    url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function setup() {
  $("eventSelect").innerHTML = E.map(
    (e) => `<option value="${e.id}">${e.date} · ${esc(e.short)}</option>`,
  ).join("");
  $("eventSelect").value = state.event;
  $("eventSelect").onchange = (e) => showEvent(e.target.value);
  $("windowSelect").onchange = (e) => {
    state.window = e.target.value;
    renderFocus();
    renderHeatmap();
  };
  ["cryptoMode", "stableMode"].forEach((id) => ($(id).onchange = renderMain));
  $("eventGroup").onchange = renderEventChart;
  ["category", "stockMetric", "rangeEvents"].forEach(
    (id) => ($(id).onchange = renderHeatmap),
  );
  document.querySelectorAll("[data-range]").forEach(
    (b) =>
      (b.onclick = () => {
        const ranges = {
          all: [D.start, D.end],
          2020: ["2020-01-01", D.end],
          2023: ["2023-01-01", "2023-12-31"],
          2025: ["2025-01-01", "2025-12-31"],
          2026: ["2026-01-01", D.end],
        };
        applyRange(...ranges[b.dataset.range]);
        b.classList.add("active");
      }),
  );
  $("applyRange").onclick = () =>
    applyRange($("startDate").value, $("endDate").value);
  $("zoomEvent").onclick = () => {
    let d = idx(event().date);
    applyRange(
      dates[Math.max(0, d - 30)],
      dates[Math.min(dates.length - 1, d + 30)],
    );
    $("cryptoChart").scrollIntoView({ behavior: "smooth", block: "center" });
  };
  $("moverAsset").innerHTML = [
    "BTC",
    "ETH",
    "SOL",
    "CRCL",
    "COIN",
    "PYPL",
    "HOOD",
    "V",
    "MA",
  ]
    .map((k) => `<option>${k}</option>`)
    .join("");
  $("moverAsset").onchange = renderMovers;
  $("coverage").innerHTML =
    "<table><thead><tr><th>자산</th><th>역할</th><th>첫 관측</th><th>최종 관측</th><th>관측수</th><th>데이터 원문</th></tr></thead><tbody>" +
    Object.entries(A)
      .map(
        ([k, a]) =>
          `<tr><td>${k}</td><td>${esc(a.name)}</td><td>${a.start}</td><td>${a.end}</td><td>${a.n.toLocaleString()}</td><td><a href="${a.url}" target="_blank" rel="noopener">Yahoo</a>${a.cm ? ` / <a href="${a.cm}" target="_blank" rel="noopener">초기 Coin Metrics</a>` : ""}</td></tr>`,
      )
      .join("") +
    "</tbody></table>";
  $("sources").innerHTML = E.map(
    (e) =>
      `<li><span>${e.id} · ${e.date} · <a href="${e.url}" target="_blank" rel="noopener">${esc(e.label)}</a></span><small>${esc(e.note)}</small></li>`,
  ).join("");
  $("downloadPrices").onclick = () => {
    let rows = [];
    for (const [k, a] of Object.entries(A)) {
      let prev = null;
      for (let i = 0; i < dates.length; i++) {
        if (a.p[i] == null) continue;
        const ret =
          prev != null
            ? a.kind === "yield"
              ? (a.a[i] - prev) * 100
              : (a.a[i] / prev - 1) * 100
            : null;
        rows.push([
          dates[i],
          k,
          a.name,
          a.p[i],
          a.a[i],
          a.kind === "yield" ? "yield_percent" : "USD",
          ret,
          a.kind === "yield" ? "bp" : "percent",
          a.kind === "stable" ? (a.p[i] - 1) * 10000 : null,
          dates[i] < a.yahooStart ? "Coin Metrics PriceUSD" : "Yahoo Finance",
        ]);
        prev = a.a[i];
      }
    }
    csvDownload(
      "stablecoin_daily_prices_2015_202609.csv",
      [
        "date",
        "asset",
        "name",
        "close",
        "adjusted_close",
        "level_unit",
        "change_from_previous_observation",
        "change_unit",
        "peg_deviation_bp",
        "source",
      ],
      rows,
    );
  };
  $("downloadEvents").onclick = () =>
    csvDownload(
      "stablecoin_events.csv",
      [
        "event_id",
        "announcement_date",
        "crypto_anchor",
        "stock_anchor",
        "title",
        "category",
        "policy_direction",
        "scope",
        "source_url",
        "notes",
      ],
      E.map((e) => [
        e.id,
        e.date,
        e.cryptoDate,
        e.stockDate,
        e.label,
        e.category,
        e.direction,
        e.scope,
        e.url,
        e.note,
      ]),
    );
  $("downloadReturns").onclick = () => {
    const headers = [
      "event_id",
      "announcement_date",
      "asset",
      "window",
      "t0",
      "base_date",
      "end_date",
      "base",
      "end",
      "change",
      "unit",
      "peg_end_bp",
      "peg_change_bp",
      "excess_spy_pp",
      "overlapping_events",
    ];
    let rows = [];
    for (const e of E)
      for (const [k, r] of Object.entries(e.responses))
        for (const [w, v] of Object.entries(r.windows)) {
          let obj = {
            event_id: e.id,
            announcement_date: e.date,
            asset: k,
            window: w,
            ...v,
          };
          rows.push(headers.map((h) => obj[h]));
        }
    csvDownload("stablecoin_event_responses.csv", headers, rows);
  };
  $("downloadDummies").onclick = () => {
    const cats = Object.keys(categories);
    csvDownload(
      "stablecoin_daily_event_dummies.csv",
      ["date", ...E.map((e) => e.id), ...cats.map((c) => "count_" + c)],
      dates.map((d) => [
        d,
        ...E.map((e) => +(e.date === d)),
        ...cats.map(
          (c) => E.filter((e) => e.date === d && e.category === c).length,
        ),
      ]),
    );
  };
  $("downloadData").onclick = () =>
    download(
      "stablecoin_event_study_data.json",
      JSON.stringify(D),
      "application/json",
    );
  renderFocus();
  renderMain();
  renderEventChart();
  renderHeatmap();
  renderDetail();
  renderMovers();
  let timer;
  addEventListener("resize", () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      renderMain();
      renderEventChart();
    }, 150);
  });
}
try {
  setup();
  window.dashboardReady = true;
} catch (e) {
  console.error(e);
  document
    .querySelector("main")
    .insertAdjacentHTML(
      "afterbegin",
      '<div class="error">화면 초기화 오류: ' + esc(e.message) + "</div>",
    );
}
